from django.apps import AppConfig


class ProductionsConfig(AppConfig):
    name = 'productions'
